# Examples

These are the minimum test scenarios. Each must produce a valid roadmap (or, for 4 and 5, the correct intake behavior). Use them to sanity-check that the skill adapts by domain, not to copy output verbatim.

## Test 1: no Python -> data analysis, 4 months, 10h/week

Input: "我完全不会 Python，想在 4 个月内学会数据分析，每周 10 小时。"

Expected:
- Verdict: mostly feasible with adjustments (narrow to single-topic analysis).
- Skill tree: Python basics -> data handling (pandas) -> analysis/viz -> one project.
- Critical path: Python 基础 -> 数据清洗 -> 分析与可视化 -> 完整项目.
- Project ladder: 练手脚本 -> 清洗数据集 -> 分析报告 -> 作品集项目.
- Resources per phase; a not-yet branch (e.g. do not learn deep learning yet).
- Assumptions for anything not given (e.g. no deadline beyond 4 months, no English status).

## Test 2: some Python + a bit of ML -> AI in 6 months

Input: "我会 Python 和一点机器学习，想在 6 个月内转 AI。"

Expected:
- Probe what "一点机器学习" means behaviorally before assuming (e.g. did they train a model? read a doc?). Ask a minimal follow-up if needed, then continue.
- Feasibility depends on how much math/ML they already have; give a range and an intermediate goal.
- Critical path: probability/linear algebra (if missing) -> ML basics -> deep learning -> a project, or a reduced path if math is weak.

## Test 3: grad exam, math + subject, 8 months

Input: "我准备考研，希望 8 个月内完成数学和专业课复习。"

Expected:
- Translate "项目" into the domain's proof: timed mocks, error notebook, stage tests.
- Skill tree branches: 数学 (高数/线代/概率) and 专业课, each with prerequisites and parallel study.
- Assessment system uses mock score thresholds as exit criteria.
- Risky if weekly hours unknown; ask for the two feasibility levers (weekly hours, target school/syllabus) if absent.

## Test 4: vague goal ("提高英语")

Input: "我想提高英语，但没有明确目标。"

Expected:
- Do NOT invent a route. Help define the goal first: which ability (reading/listening/speaking/exam/work), by when, to what outcome.
- Only after it is concrete do you produce a roadmap. Give a very small set of options if helpful.

## Test 5: no goal ("帮我做学习规划")

Input: "帮我做一个学习规划。"

Expected:
- Enter Intake. Do not assume a topic. Run the one-shot questionnaire or form, asking what to learn, why, target level, deadline, current level, weekly time, and constraints.
- Label that the plan cannot start until a target exists.

## Behavior checklist

For every example, confirm all of:

- One-shot intake (form or single questionnaire), then automatic planning. No copy-paste of a prompt.
- Never re-ask what the user already gave.
- Assumptions always stated with impact.
- Time shown as ranges, not false precision.
- Route map + timeline present (mermaid or ASCII).
- Resources per phase, never a giant list; a "do not study yet" branch exists.
- Exit criteria per phase.
- Critical path and a minimum viable route included.

## Presentation regression: 数模研赛 + LLM 实习

This is the primary presentation test. Input: a student mid-way through a math-modeling competition sprint who also wants to build toward a large-model application internship. Run the full report pipeline and apply references/output-format.md, references/presentation-style.md, and references/visualization.md.

The result must show a clear improvement in these eight places (compare against the old flat output):

1. Abstract — a headline verdict, a Planning Snapshot table, and a one-line route.
2. Feasibility — Conclusion first, then Evidence / Implication / Decision; a time-budget comparison instead of a bare verdict.
3. Skill Tree — a Mermaid `flowchart TD` with short nodes, explanation below the figure.
4. Roadmap — a `flowchart LR` with the core route solid and parallel branches dashed.
5. Timeline — a separate ASCII or Gantt timeline, not merged into the skill tree.
6. Phase Cards — a uniform per-stage block (goal, learning, practice, project, deliverable, exit criteria, resources) plus a Stage Outcome line.
7. Risk Analysis — a compact matrix plus a callout for the single highest-priority risk.
8. Start Here — a task-command-center Day 1 with completion criteria.

Expected verdict for the sample: Feasible with adjustments. Core strategy is staged focus (finish the competition, then switch to the LLM application line). The full sample output is delivered as a separate demonstration file (`roadmap-example-report.md`) in the `outputs/` folder; it is a showcase of the report style and is NOT shipped inside this skill package, so it does not get confused with this behavioral spec.
