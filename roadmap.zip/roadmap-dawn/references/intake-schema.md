# Intake Schema

This file defines the standardized Planning Context and the two Intake paths (structured Form and one-shot questionnaire). Pass 1 reads this; Pass 2 consumes the Planning Context.

## Planning Context (single source of truth)

Normalize every answer into this YAML shape before generating. Fields are adjustable by domain, but keep the grouping. Fill defaults for anything the user did not say and mark it `assumption: true`.

```yaml
planning_context:
  current_state:
    identity:            # student / professional / job-seeker / parent / switched career ...
    background:          # major, field, current role
    education:
    experience:          # years or concrete projects
    known_skills:        # what they can actually do (behavior-based, not self-score)
    evidence_of_skill:   # scripts written, git used, docs read, debugged, shipped, exams passed
    weak_areas:          # what is missing / shaky
    current_projects:    # any live tooling, stack, or portfolio
  goal:
    target:              # the concrete capability, not the topic name
    motivation:          # why this matters (job, exam, application, interest)
    target_level:        # "can X independently", "pass Y", "take on a Z role"
    deadline:            # date or "in N months"
    success_criteria:    # how we will know it worked
    deliverables:        # project, portfolio piece, exam score, artifact
  time:
    hours_per_week:
    weekday_hours:
    weekend_hours:
    schedule_constraints:  # exam week, busy season, travel, family, job spikes
    usable_ratio:          # default 0.7-0.85 (buffer); set lower when erratic
  resources:
    courses:
    books:
    documentation:
    mentor:
    budget:
    tools:
    english_comfort:       # can they read English docs? yes / some / no
    web_access:            # can the agent search live?
  preferences:
    learning_style:        # video / book / doc / project / problem / theory
    language:
    theory_vs_practice:
    preferred_formats:
  constraints:
    exams:
    work:
    school:
    financial:
    hardware:
    other:                 # hard blockers, travel, childcare
  output_preferences:
    detail_level:          # brief / standard / deep
    daily_schedule:        # only if requested
    resources:
    projects:
    mindmap:
    assessments:
    long_term_route:
```

## Assess current state by behavior, not by score

Prefer evidence over "I'm a 3/10". Use these probes as a checklist; each answer should map to a verb the user has done.

- Wrote a standalone script that runs end to end.
- Used functions, classes, exceptions, imports.
- Used Git: init, commit, branch, merge, resolve conflict.
- Read an official doc and implemented something from it.
- Debugged an error by reading a traceback / logs on their own.
- Built or shipped something real (app, report, dataset, portfolio).
- For non-coding: wrote a structured essay, recorded a talk, ran an analysis, produced a design, passed a practice exam.

Map each capability to `evidence_of_skill` as `can/cannot + concrete verb`, e.g. `can: "write functions"`, `cannot: "use Git"`.

## Path A: Structured Intake Form (when the host supports a real form / UI)

Present one form with all sections at once. Group into 7 blocks matching the schema:

1. Goal (what, why, target level, deadline, success).
2. Current level (background, experience, evidence-based skills, weak areas).
3. Time (weekly + weekday/weekend + recurring busy).
4. Conditions (courses, books, docs, mentor, budget, tools, English, web access).
5. Preferences (style, theory vs practice, format).
6. Constraints (exams, work, school, financial, hardware, other).
7. Output preferences (detail, daily plan, resources, projects, mindmap, assessments, long-term route).

On submit: do NOT ask the user to copy anything. Normalize answers into `planning_context`, then continue straight to Pass 2. One fill -> automatic planning.

## Path B: One-shot questionnaire fallback (no form available)

Emit a single compact questionnaire covering all sections at once, and ask the user to reply in one message. Never fall back to asking one question per turn.

Template (keep terse; adjust wording to the user's domain):

```
为了给你制定真正能执行的学习路线，请一次性回答下面几项（不清楚的写"不确定"即可）：

1. 目标：想学会/掌握什么？希望达到什么水平？截止日期？怎么算成功？
2. 现状：你的背景/专业/工作经验？现在能独立做到什么？（比如写过脚本、用过 Git、做过项目、读过官方文档）哪里最弱？
3. 时间：每周能投入多少小时？工作日多少、周末多少？有没有周期性忙碌？
4. 资源：有没有课程/书/文档/导师？预算大概多少？能读英文资料吗？需要上网查最新资料吗？
5. 偏好：喜欢视频、看书、看文档、做项目、刷题，还是先学理论？
6. 约束：有没有考试/工作/学业/预算/设备等硬性限制？
7. 输出：要详细还是简要？要不要每日安排、资源、项目建议、思维导图、阶段测试、长期路线？

一次性回复后，我会自动整理成计划并直接生成完整路线，不需要你再粘贴任何内容。
```

## Minimum Necessary Questions rule

Only ask what materially changes feasibility or sequencing. Assume everything else and label the assumption. Rules:

- Never re-ask what the user already stated (identity, goal, deadline, weekly time).
- If the user gave a goal but no deadline or weekly hours, ask ONLY those two, because feasibility depends on them.
- If the goal is vague ("提高英语 / improve English"), first help define it (see below), then continue. Do not invent a route.
- If a field barely affects the plan (preferred video vs book when total time already tells the story), default sensibly and state it.

## Degradation rule

After the one-shot questionnaire, only ask a follow-up when the missing item would change the feasibility verdict or the critical path. For example: "You didn't say how many hours/week you can commit; this is the single biggest lever on whether 4 months is realistic. Roughly how many hours per week?" Do not grind through a checklist field by field.

## Vague goal handling

If the goal is not actionable, convert it into a decision instead of planning:

- "提高英语" -> ask: which ability? (reading / listening / speaking / exam / work). By when? To what outcome (pass X, hold a 15-min meeting, read a paper)?
- "转行" -> ask: to what role? What is the proof you need (portfolio, certificate, job offer, applied project)?
- Only after the target capability is concrete do you move to decomposition.

## Assumption management

For anything you assume, record both the assumption and its possible impact so the user can correct cheaply.

```yaml
assumptions:
  - item: "每周可投入 10 小时"
    basis: "用户未提供"
    impact_if_wrong: "若实际只有 6 小时，路线预计延长 5-7 周"
```
