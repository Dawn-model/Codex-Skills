# Visualization

The diagrams are part of the Presentation Layer. They express structure only; explanation goes in text below the figure. Prefer Mermaid; fall back to a compact ASCII version if Mermaid does not render. Never leave a diagram section empty.

## Skill tree (Mermaid preferred)

Use a `flowchart TD` with short node names and clear levels. Do not put long sentences in nodes. ASCII tree is fallback only.

```mermaid
flowchart TD
    A["目标：LLM 应用实习"]
    A --> B["基础能力"]
    A --> C["LLM 应用"]
    A --> D["AI 工程"]
    A --> E["交付能力"]
    B --> B1["Python"]
    B --> B2["NumPy / Pandas"]
    B --> B3["Machine Learning"]
    C --> C1["LLM API"]
    C --> C2["Prompt"]
    C --> C3["RAG"]
    C --> C4["Agent"]
    D --> D1["Git"]
    D --> D2["Codex / Cursor"]
    D --> D3["Testing / Review"]
    E --> E1["FastAPI"]
    E --> E2["Frontend"]
    E --> E3["Deployment"]
    C4 --> E1
```

Explain the tree below the figure.

## Roadmap (the core visual)

Use `flowchart LR`. Solid edges for the main route, dashed for parallel/optional; if the renderer supports color, use grayscale for optional.

```mermaid
flowchart LR
    A["Phase 0<br/>数模冲刺"] --> B["Phase 1<br/>LLM 基础"]
    B --> C["Phase 2<br/>RAG / Agent"]
    C --> D["Phase 3<br/>作品集"]
    D --> E["Phase 4<br/>申请"]
```

Parallel version:

```mermaid
flowchart LR
    A["核心路线"] --> B["LLM 应用"]
    B --> D["并行：工具能力"]
    B -.-> C["并行：ML 广度"]
```

Rules:

- Core route solid; non-critical dashed.
- Optional items use grayscale when supported.
- Never put a paragraph inside a node.
- Node labels short.

## Timeline (separate section)

Keep timeline separate from the skill tree. Prefer Mermaid Gantt; fall back to a clean ASCII timeline.

Mermaid Gantt:

```mermaid
gantt
    dateFormat YYYY-MM-DD
    axisFormat %Y.%m
    title Learning Route
    section Phase 0
    数模冲刺          :a1, 2026-09-01, 4w
    section Phase 1
    LLM 基础          :a2, after a1, 3w
    section Phase 2
    RAG / Agent       :a3, after a2, 4w
    section Phase 3
    作品集            :a4, after a3, 4w
```

ASCII fallback:

```text
2026.09        2026.10        2026.11        2026.12        2027.01
│--------------│--------------│--------------│--------------│

数模冲刺
████████

LLM 基础
              ████████

RAG / Agent
                           █████████

Final Project
                                      ███████████

申请 / 实习
                                                   ████████
```

## Current position progress bar

Use text if the renderer cannot draw a real bar.

```text
CURRENT POSITION
████████░░░░░░░░░░░░
Phase 0 / 4
```

## Compatibility rules

- Markdown heading, blockquote, table, code block, Mermaid (if supported), and horizontal rule must look good in plain Markdown.
- Do not depend on custom CSS.
- If Mermaid is unsupported, always include ASCII for route map and timeline.
- Keep figures to structure; the prose carries meaning.
