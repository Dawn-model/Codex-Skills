# Roadmap Output Format

This file defines the structure of the final document. It is a Publication/Presentation spec: it decides organization and hierarchy. The content itself comes from the Planning Engine. Follow references/presentation-style.md for typography, callouts, tables, and length.

Write the content in the user's language. Adapt section names to the domain; add or drop chapters by complexity. Do not force all ten chapters on a simple goal.

## Report header (cover-style)

Open with a short report header, not straight into a numbered chapter.

```markdown
# 学习规划报告

### 数模研赛冲刺 × 大模型应用实习

**Roadmap Edition · 2026.09**

> A structured roadmap based on current capability, target outcomes, time constraints and execution capacity.

---

**目标周期** · 2026.09 → 2027.01
**核心目标** · 数模竞赛 / 大模型应用实习
**规划状态** · Feasible with adjustments
**核心策略** · 先完成近期硬目标，再切换长期主线
---
```

Keep it spare. No heavy decoration.

## Abstract

Replaces the old flat bullet list. Three parts:

1. **核心结论** — the headline verdict as a blockquote.

```markdown
> 当前目标整体可行，但必须采用"阶段性聚焦"的策略：近期集中突破数模竞赛，赛后立即切换至 LLM 应用主线。
```

2. **Planning Snapshot** — a small two-column table for the key dimensions.

```markdown
| Dimension | Assessment |
| --- | --- |
| Short-term Goal | 数模研赛 |
| Long-term Goal | LLM 应用实习 |
| Feasibility | Feasible with adjustments |
| Critical Constraint | Available time |
| Primary Risk | Learning without output |
| Core Strategy | Build while learning |
```

3. **一句话路线** — one visually obvious route line (a single line, the main anchor).

```text
Python / Data Foundation
        ↓
Modeling Practice
        ↓
LLM API
        ↓
RAG / Agent
        ↓
Production Project
        ↓
Internship
```

This is one of the strongest visual anchors of the whole document.

## Recommended structure (complex goal)

```markdown
# 学习规划报告
Subtitle
Metadata

---

## Abstract
核心结论 / Planning Snapshot / 一句话路线

## 01 目标与现状
Current State / Target State / Gap

## 02 可行性评估
Feasibility / Time Budget / Constraints / Key Decisions

## 03 能力模型
Goal Decomposition / Skill Tree / Critical Path

## 04 学习路线
Roadmap Diagram / Timeline

## 05 阶段实施方案
Phase 0 / Phase 1 / Phase 2 / ...

## 06 项目与成果
Project Ladder / Deliverables / Portfolio

## 07 评估体系
Knowledge Check / Skill Check / Exit Criteria

## 08 风险与调整
Risk Matrix / Contingency Plan

## 09 Minimum Viable Path
60% 时间版本 / Deadline 崩溃版本

## 10 Long-term Development
后续方向

---

# Start Here
Today / This Week / Next Milestone
```

Adapt to the task. For a simple goal, this collapses to Abstract, 目标与现状, 可行性, 能力模型, 学习路线, 阶段实施方案, Start Here.

## Section body: conclusion first

Each major section opens with the conclusion, then evidence, then implication, then decision.

```markdown
## 02 可行性评估

> **结论：可行，但必须压缩理论学习，把实践放到关键路径。**

### Evidence
...
### Implication
...
### Decision
...
```

## Skill tree (prefer Mermaid)

Do not use a giant ASCII tree as the main visual. Prefer Mermaid. Put the explanation below the figure.

```mermaid
flowchart TD
    A["目标：LLM 应用实习"]
    A --> B["基础能力"]
    A --> C["LLM 应用"]
    A --> D["AI 工程"]
    A --> E["交付能力"]
    B --> B1["Python"]
    B --> B2["NumPy / Pandas"]
    B --> B3["Machine Learning"]
    C --> C1["LLM API"]
    C --> C2["Prompt"]
    C --> C3["RAG"]
    C --> C4["Agent"]
    D --> D1["Git"]
    D --> D2["Codex / Cursor"]
    D --> D3["Testing / Review"]
    E --> E1["FastAPI"]
    E --> E2["Frontend"]
    E --> E3["Deployment"]
    C4 --> E1
```

Node names are short. The diagram only expresses structure. If Mermaid does not render, fall back to a compact ASCII tree, never a huge one.

## Roadmap diagram (the core visual)

Use a `flowchart LR`. Solid edges for the main path, dashed for parallel/optional.

```mermaid
flowchart LR
    A["Phase 0<br/>数模冲刺"] --> B["Phase 1<br/>LLM 基础"]
    B --> C["Phase 2<br/>RAG / Agent"]
    C --> D["Phase 3<br/>作品集"]
    D --> E["Phase 4<br/>申请"]
```

Parallel example:

```mermaid
flowchart LR
    A["核心路线"] --> B["LLM 应用"]
    B --> D["并行：工具能力"]
    B -.-> C["并行：ML 广度"]
```

## Timeline (separate section)

Keep the timeline separate from the skill tree. Prefer Mermaid Gantt; fall back to a clean ASCII timeline.

```text
2026.09        2026.10        2026.11        2026.12        2027.01
│--------------│--------------│--------------│--------------│

数模冲刺
████████

LLM 基础
              ████████

RAG / Agent
                           █████████

Final Project
                                      ███████████

申请 / 实习
                                                   ████████
```

## Stage cards

Every phase uses the exact same structure, no ad-hoc key-value piles.

```markdown
### Phase 01 · LLM 应用基础

**2026.09.27 — 2026.10.18 · 35–45 h**

> **阶段目标**
> 能独立调用 LLM API，并交付一个可运行的聊天应用。

#### Learning
Python 补强、HTTP、API、Prompt、Streamlit

#### Practice
API 调用、会话管理、简单 UI

#### Project
Streamlit Chat Application

#### Deliverable
可运行项目 + README

#### Exit Criteria
能够独立完成……

#### Primary Resources
官方文档 / 主课程
```

End every stage with a **Stage Outcome** line:

> **Stage Outcome**
> 完成本阶段后，你应该从"能够学习 X"进入"能够独立完成 Y"。

## Resources (redesigned)

No long flat bullet list. Group into Primary / Documentation / Optional / Deferred, and state what to do or defer.

```markdown
## Resources

### Primary
**XXX**
用途：……

### Documentation
**Official Documentation**
用途：……

### Optional
**XXX**
仅在 XXX 情况下使用。

### Deferred
暂不学习：
- XXX
- XXX
```

Emphasize what to study now, why, and what not to study yet.

## Risk analysis (research style)

Risk matrix plus a callout for the single highest-priority risk.

```markdown
| Risk | Likelihood | Impact | Response |
| --- | ---: | ---: | --- |
| … | High | High | … |

### Highest-priority Risk

> **学习输入高、输出低。**

**Mitigation**
每个阶段必须有可验证交付物。
```

## Current position module

Tell the reader where they are right now, early.

```text
CURRENT POSITION

████████░░░░░░░░░░░░

Phase 0 / 4

当前阶段：数模研赛冲刺
Next Milestone：完成第一道真题
Deadline：2026.09.23
```

If the renderer cannot make a real progress bar, use text.

## Execution horizon (Now / Next / Later)

Near the end, before the action panel.

```markdown
## Execution Horizon

### NOW
未来 7 天：……

### NEXT
赛后第一周：……

### LATER
11 月以后：……
```

## Start Here (final action panel)

The most usable execution entry point. Not a numbered list buried in a chapter.

```markdown
# Start Here

> **今天不要考虑整条路线。只执行下面 5 件事。**

### Day 1
**01** …
**02** …
**03** …

### Completion Criteria
今天完成以下条件即可结束：
- [ ] …
- [ ] …
- [ ] …
```

## Rules applied to every document

- Title is `#`; major sections `##`; subsections `###`; detail `####`. Stable hierarchy.
- One page carries one main logic; merge tiny sections.
- Conclusion first (Conclusion → Evidence → Implication → Decision).
- Tables only for two-dimensional comparison; no prose in cells.
- Max four callout types: Decision / Key Insight / Constraint / Warning.
- Bold only for conclusions, key nouns, status, important numbers; max ~3 per paragraph.
- No emoji.
- Unified date/number/term formats.
- State once, reference elsewhere; no repetition.
- Main report is concise; details go in a separate expandable section.
- Length adapts to complexity (1000-2000 / 2000-4000 / 4000-7000), not unbounded.
