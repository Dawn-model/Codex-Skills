# Planning Framework

This file is the engine Pass 2 runs. Follow the order strictly: define the goal as a capability, then the competencies, then the skill tree, then dependencies, then path, then content, then time. Never start from a course list.

## 1. Goal Decomposition

Goal -> Target Capability -> Required Competencies -> Skill Tree -> Prerequisites -> Learning Sequence -> Practice -> Proof.

State the target as a capability sentence, not a topic:

- Wrong: "want to learn machine learning."
- Right: "within 6 months, independently complete a machine-learning analysis and apply for a data/algorithm internship."

Break it down:

- **Target capability**: what the person must be able to do at the end.
- **Competencies**: the 3-6 broad abilities that compose it.
- **Skills**: concrete, verifiable sub-skills under each competency.
- **Prerequisites**: skills that must exist before the target skills make sense.
- **Proof**: a deliverable or test that demonstrates the competency.

## 2. Skill Tree

Express as a hierarchy that feeds the route. It is a planning aid, not decoration.

```text
Target Capability
├── Foundation
│   ├── A
│   ├── B
│   └── C
├── Core
│   ├── D
│   ├── E
│   └── F
├── Tooling
│   ├── G
│   └── H
└── Applied
    ├── Project 1
    ├── Project 2
    └── Final Project
```

Adapt branches per domain. For an exam, `Applied` becomes `真题 / 模拟考试 / 错题本`; for English, `Applied` becomes `写作 / 口语录音 / 阅读测试`.

## 3. Dependency / Critical Path Analysis

Label every skill on the tree:

- **Prerequisite**: must be learned before the dependent skill. Do not skip.
- **Blocking**: a gate; if incomplete, later phases cannot start.
- **Parallelizable**: can be studied alongside other skills (e.g. Git while learning syntax).
- **Optional**: nice to have; cut first when time is short.
- **Advanced**: only after core is solid; not required for minimum viability.

Then build a DAG and find the critical path -- the chain that must finish on time for the whole plan. Ask: "if I cut one thing, which link still gates everything?" That is the critical path. Mermaid is preferred for this; see visualization.md.

```text
A → B → C → D   (critical path)
      ↘ E ↗
        F       (parallel / optional)
```

## 4. Time Budget (actual arithmetic)

Estimate, do not assert. Use ranges, never false precision.

```text
available_hours = hours_per_week × weeks_before_deadline
usable_hours    = available_hours × usable_ratio (default 0.70–0.85)
```

`usable_ratio` is the buffer for fatigue, review, forgetting, exam weeks, and slippage. Lower it (0.65) for erratic schedules; raise it (0.85) only for a very predictable routine.

Total needed:

```text
needed_hours = learn + practice + build + review_buffer
```

Compare:

- `needed < usable` -> feasible.
- `needed ≈ usable` -> feasible with adjustments (tighten scope or extend).
- `needed > usable × 1.2` -> scope reduction required.
- `needed > usable × 1.6` -> deadline unrealistic; propose a lower target or longer horizon.

Do not "compress" time to make it fit. If it does not fit, say so and offer the cheapest lever: cut scope, extend deadline, or lower the target level.

## 5. Route Design (four content types per phase)

Every phase includes all of:

- **Learn**: what to study.
- **Practice**: how to drill it (exercise set, flashcards, drills, problem sets).
- **Build**: what to make (project, artifact, mock task, practice paper).
- **Validate**: how to prove it (knowledge check + skill check + deliverable + exit criteria).

Example phase:

```
Phase 2 - SQL (weeks 3-5)
Learn: JOIN, GROUP BY, window functions.
Practice: 20 SQL exercises.
Build: analyze a real dataset.
Validate: write SQL for 10 business questions unaided.
Exit criteria: can write the above without looking up syntax.
```

## 6. Resource Assignment (serves the route)

Per phase, give:

```text
Primary Resource: <name> (why: this phase needs X).
Optional: <name>.
Practice: <name or set>.
Do not study yet: <name>.
```

Rules:

- Prefer official docs and canonical, stable resources.
- Never fabricate course names, book titles, URLs, prices, or version numbers.
- For time-sensitive stacks (AI tooling, frameworks, languages, job market, current docs), search live before recommending.
- Explicitly tell the user what NOT to study now, to cut information anxiety.

## 7. Project Ladder

Project 0 (warm-up) -> Project 1 (basic) -> Project 2 (comprehensive) -> Final Project (portfolio). For non-coding, rename to the domain's proof artifact: for exams use mock papers / error notebooks; for writing use published pieces / readings.

Each project states: goal, tools/tech used, problem it solves, the parts the learner must do unaided, and the acceptance criteria.

## 8. Assessment System

Per phase, define:

- **Knowledge check**: did they understand it.
- **Skill check**: can they actually do it.
- **Deliverable**: a finished artifact.
- **Exit criteria**: the concrete gate to move on.

Example exit gate:

```
Before Phase 3:
✓ use Git independently (init, commit, branch, merge).
✓ explain commit / branch / remote.
✓ resolve a common conflict alone.
✓ committed a project.
```

For exams: exit criteria = a threshold score on a timed mock. For English: produce a graded-style piece / recording.

## 9. Risk Engine

For each risk, give Probability / Impact / Mitigation. Cover at least:

- Not enough time.
- Weak prerequisites.
- Goal too high (too broad or too deep).
- Wrong resource choice (outdated or low quality).
- Only watching, not practicing.
- Project too hard (sunk time without progress).
- No feedback loop (no mentor, no review, no check).
- Burnout / low consistency.

```yaml
risk:
  name: "只看视频不练习"
  probability: "high"
  impact: "critical"
  mitigation: "每周强制 1 个交付物；每学一段就做一个最小练习；不进入下一章直到当前练习通过"
```

## 10. Minimum Viable Roadmap

Always provide two things:

- **If only ~60% of time remains**, what to cut: drop Optional and Advanced branches first; compress the Final Project to a smaller scope; keep the critical path intact.
- **If the target cannot be met by the deadline**, the most reasonable intermediate goal: a smaller, achievable version that still counts as real progress and can be extended later.

## 11. Assumption Management

Record every assumption and its impact so the user can correct cheaply. Present as:

```yaml
assumptions:
  - item: "每周可投入 10 小时"
    impact_if_wrong: "若实际只有 6 小时，路线预计延长约 5-7 周"
```

## 12. Domain Adaptation

Do not hardcode a tech stack. Adapt the framework per field, changing only the content of Practice / Build / Assessment / Resource types:

- Programming / AI / data: projects, repos, datasets, code review.
- Math / exam prep: problem sets, timed practice, error notebook, mock tests.
- English: input (reading/listening) + output (writing/speaking), graded samples.
- Product / design: case studies, portfolio artifacts, review cycles.
- Writing: drafts, revisions, published pieces, read-aloud, peer review.
- Academic research: literature review, method design, pilot study, paper draft.

The framework stays identical; only the nouns change.
