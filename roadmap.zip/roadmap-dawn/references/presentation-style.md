# Presentation Style

This file defines the Presentation Layer. The Planning Engine produces correct content; this layer decides how it is organized, layered, and rendered so the result reads like an edited research / consulting report, not a long AI chat reply.

## Two layers

```text
Planning Engine  (correctness)
        |
        v
Planning Model   (the roadmap content)
        |
        v
Presentation Engine  (readability)
        |-- Information Hierarchy
        |-- Section Design
        |-- Typography
        |-- Tables
        |-- Callouts
        |-- Timeline
        |-- Roadmap Diagram
        `-- Final Action Panel
        |
        v
Final Document
```

Never redesign the plan to improve looks. Reorganize the presentation only.

## Overall style: Academic / Research Report

Keywords: restrained, professional, clear, rational, strong information structure, generous whitespace, no ornament.

Target feel: an academic paper, a strategy consultant report, a high-quality industry whitepaper, a graduate research plan. Not a Notion template, a blog, a knowledge-creator post, an emoji note, or a default ChatGPT answer.

## Heading hierarchy (strict)

Only four levels are allowed. Do not invent deeper or repeated levels.

```text
# Document Title

## Major Section

### Subsection

#### Detail
```

Banned:

```text
### ### 阶段1
##### ###
####### 阶段
```

This means the report title is `#`, major parts `##`, sub-parts `###`, and only true detail goes to `####`. Do not use headings to shout.

## Section count and consolidation

One page carries one main logic. If several chapters belong to one unit, merge them instead of emitting many tiny `##` headings.

Example: "Goal Decomposition + Skill Tree + Critical Path" should be one major section `## 03 能力模型` with three `###` subsections, not three separate numbered top-level headings.

Do not force every report to contain all ten chapters. Add or drop based on complexity.

## Chapter design: conclusion first

Every major section uses this internal rhythm:

```text
## 02 可行性评估

> **结论：可行，但必须压缩理论学习，把实践放到关键路径。**

### Evidence
...
### Implication
...
### Decision
...
```

That is **Conclusion -> Evidence -> Implication -> Decision**. The reader should get the point before the supporting text. Never make the reader finish a long paragraph to learn the conclusion.

## Reading hierarchy

Layer every complex topic:

```text
Level 1: Heading
Level 2: One-sentence conclusion (blockquote / bold)
Level 3: Structured body
Level 4: Details / data / explanation
```

The reader should be able to grasp the whole thing from headings, blockquotes, bold, and diagrams alone, and only dip into the body when they need depth.

## Callouts (a small fixed set)

Use blockquote callouts for important judgments. Keep the set small, no more than these four:

> **Decision**
> content

> **Key Insight**
> content

> **Constraint**
> content

> **Warning**
> content

Do not invent a dozen callout styles. A callout is one short line (the label) plus one to three sentences.

Formats that both serve as decision boxes and reduce clutter:

> **Planning Decision**
> 未来 17 天不启动 LLM 主线。
> 原因：数模竞赛为硬 deadline，且 Python / 数据处理能力本身会成为赛后 LLM 路线的基础。

> **Not on Critical Path**
> 当前不学习大模型训练、LoRA 微调等内容。

## Visual anchors

Every long report needs several unmistakable anchor points. The reader should get about 70% of the message from scanning bold labels and diagrams:

- Anchor 1: the final goal
- Anchor 2: the full route
- Anchor 3: the critical path
- Anchor 4: the current phase
- Anchor 5: today / next action

## Table rules (reduce table abuse)

Use tables only for genuinely two-dimensional comparison. Good:

- Phase / time / goal / milestone
- Risk / probability / impact / response
- Week / goal / practice / deliverable

Not good: tables used for long explanations, learning methods, project descriptions, resource introductions, or complex logic.

If a table cell would need two or three sentences, switch to normal text. Prefer a compact table over a sprawling one; if a table must contain long text, restructure.

## Bold rules (control emphasis)

Do not bold every line. Bold only:

- conclusions
- key nouns/terms
- status
- important numbers

If one paragraph needs more than three bold spans, re-check it. Heavy bold flattens emphasis.

## Emoji rules

Default: no emoji. If used at all, only in rare UI-style spots. Never write fire/rocket/light-bulb/check/target/book icons. Keep the whole document academic and professional.

## Diagram rules

Prefer Mermaid. ASCII is fallback only.

- Skill Tree: a compact `flowchart TD`, short node names, clear levels.
- Roadmap: a `flowchart LR` with the core route solid and non-critical paths dashed.
- Keep diagrams to structure; put explanation below the figure, never inside node text.
- If Mermaid is not rendered, always include the ASCII version rather than leaving it empty.

## Length control

Adjust length to task complexity. "Complete" does not mean "unbounded."

- Simple goal: about 1000-2000 characters.
- Medium goal: about 2000-4000.
- Complex multi-stage goal: about 4000-7000.

Only expand further (daily plan, complete study handbook) when the user explicitly asks for extreme detail. A bigger document is not automatically better.

## Number and date format (unified)

Pick one convention and keep it through the whole document.

```text
Date:        2026.09.05
Range:       2026.09.05 → 2026.10.01
Duration:    35–45 h
Period:      4 weeks
Likelihood:  High / Medium / Low
```

Do not mix "9 月 23 日", "9/23", and "2026-09-23". Default to one within a single report.

## Terminology (unified)

Do not switch between target / Goal / Objective / Target. If both languages appear the first time, give the bilingual form once, then use the single form afterward.

```text
First:  阶段目标（Stage Objective）
Later:  阶段目标
```

Same for Deliverable, Exit Criteria, Critical Path, Feasibility.

## Avoid repetition

State something once in the body; elsewhere reference it instead of restating.

If a phase plan already covers Project 1, later in "Project Ladder" do not re-explain the whole project. Write:

```text
Project 1 → 见 Phase 2
```

or a single summarizing line.

## Split detail from the main report

The "Main Report" carries only the most important information. Expand the detail separately when needed: weekly plan, daily plan, resource details, project acceptance criteria. First screen should not have everything competing for attention.

## Anti-patterns (never do these)

- Bold almost every sentence.
- Lots of emoji.
- A dozen consecutive tables.
- A giant ASCII tree as the primary visual.
- A single-topic chapter occupying its own top-level heading.
- Re-explaining the same content.
- A table cell containing long prose.
- Padding the text to look thorough.
- Chaotic heading levels.
- Hiding an important conclusion inside a long paragraph.
- Giving every part equal visual weight.

## Quality gate (run before final answer)

Check these before emitting the document. If any fail, re-layout before output.

### Information architecture
- Can the reader quickly find the core conclusion?
- Is there a clear route?
- Are Current / Target / Gap distinguished?
- Is the critical path present?

### Visual hierarchy
- Heading levels are consistent.
- Tables are not overused.
- Bold is not overused.
- Callout types are consistent.
- Route diagram is clear.
- Timeline is clear.

### Readability
- Enough whitespace.
- No overly long paragraphs.
- No duplicate content.
- No information overload.

### Actionability
- Current phase is clear.
- Next action is clear.
- Next milestone is clear.
- Exit criteria are clear.

### Style
- No obvious AI-template feel.
- No emoji overuse.
- Not like a chat log.
- Not like a blog.
- Reads like a professional report.
