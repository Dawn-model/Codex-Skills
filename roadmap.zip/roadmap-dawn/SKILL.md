---
name: roadmap-dawn
description: Build a personalized, staged learning plan as a two-pass intake-to-roadmap agent. Given a goal, current state, time, resources and constraints, it structures an intake, derives a skill tree and dependency graph, budgets time, assigns resources, projects and assessments, and emits a feasibility verdict, phased route, milestone plan, critical path, risks, minimum viable route, and a visualized roadmap. Triggers on requests like 学习规划, 学习路线, 学习计划, 转行学, 备考, 考研, 系统学习, 从零学, or "plan my learning route or path". Not for single factual questions like "what is Python".
---

# Learning Roadmap

Turn a learning goal into a concrete, sequenced, feasible plan by reverse-engineering the target capability. Run two passes: Pass 1 gathers and structures inputs; Pass 2 generates the roadmap. Never jump straight to a topic list.

## When to Use

Use this skill when the user wants a plan for learning something, for example:

- 帮我制定学习计划 / 学习路线 / 学习路径
- 我想在 X 时间内学会 Y，怎么安排
- 我想转行 / 备考 / 考研 / 系统学习 X / 从零开始学 X
- "Help me plan my learning route", "I want to become Z"
- "Help me judge whether this goal is realistic"

Do not trigger for a one-line "recommend a course" or a single factual question (e.g. "什么是 Python" / "what is a list"). This skill is for a structured, multi-phase plan.

## Core Principle

Do not list topics just because the user wants to learn X. Start from the ability they want, then derive what to learn, why, in what order, to what level, and how to prove it.

`Goal -> Target Capability -> Competencies -> Skill Tree -> Prerequisites -> Learning Sequence -> Practice -> Proof`

## Two Layers: Plan and Present

Run two separate engines. The Planning Engine produces correct content. The Presentation Engine reorganizes it into an edited research / consulting report.

```text
Planning Engine -> Planning Model -> Presentation Engine -> Final Document
```

Never change the plan to make it look better; reorganize the presentation only. Follow references/presentation-style.md for hierarchy, section design, callouts, tables, emphasis, diagrams, terminology, and length, plus its anti-patterns and quality gate.

## Workflow

### Pass 1: Intake (references/intake-schema.md)

Do not generate a roadmap yet. First determine what info is already present and what is missing.

Minimize questions (Minimum Necessary Questions). Only ask for inputs that materially change the plan; assume the rest and label the assumption.

Collect only the missing parts:

- **Current state**: behavior-based ability (can you write a standalone script, use functions/classes/exceptions, use Git, read official docs, debug?), not a self-score. Include background, experience, known skills, weak areas, current projects/tooling.
- **Goal**: target, motivation, desired level, deadline, success criteria, deliverables.
- **Time**: hours per week, weekday vs weekend, recurring busy periods.
- **Resources**: courses, books, docs, mentor, budget, tools, English comfort, web access.
- **Preferences**: video, book, doc, project-driven, problem-driven, theory-driven.
- **Constraints**: exams, job hunt, work, school, financial, hardware, other hard limits.
- **Output preferences**: detail level, daily plan, resources, projects, mindmap, assessments, long-term route.

Two behaviors:

1. If the host environment supports a structural Form / UI: present a one-shot intake form. On submit, normalize the answers into a Planning Context (see references/intake-schema.md) and continue directly to Pass 2. Never ask the user to copy the form back.
2. If no real Form / UI is available: emit a single compact questionnaire covering all sections at once and ask the user to reply in one message. Then normalize and continue.

Degradation rule: do not fall into one-question-at-a-time. Only ask follow-ups that would materially change feasibility, and only after the one-shot questionnaire.

Do not re-ask anything the user already provided. If the goal is vague (e.g. "提高英语" / "improve English"), help define it before planning; do not invent a route.

### Pass 2: Generate (references/planning-framework.md, references/output-format.md, references/visualization.md)

Normalize the collected input into a Planning Context, then run in order:

1. Goal decomposition into capabilities (references/planning-framework.md).
2. Skill tree from the decomposition.
3. Dependency / critical-path analysis (blocking, parallel, optional, advanced).
4. Time budget and feasibility (compare available vs required hours; treat ~70-85% of ideal capacity as usable, the rest as buffer).
5. Route design: each phase covers Learn / Practice / Build / Validate.
6. Resource assignment per phase (official and classic first; never fabricate titles, URLs, prices; use live search for time-sensitive stacks).
7. Project ladder (Project 0 -> Final Project), each aligned to phase skills.
8. Stage acceptance (Knowledge Check / Skill Check / Deliverable / Exit Criteria).
9. Weekly plan (default); expand to a daily plan only on request.
10. Risk analysis (risk / probability / impact / mitigation).
11. Minimum viable route (what to cut if only ~60% time remains) and a reasonable intermediate goal if the target is unreachable in time.
12. Long-term extension (what comes after this target).
13. Final action list (very concrete Day-1 steps).

## Output

Produce the roadmap in the user's language (Chinese if they wrote Chinese). Treat it as an academic / consulting-style report, not a long chat reply.

1. Follow the report structure and stage-card format in references/output-format.md.
2. Follow references/presentation-style.md for typography, callouts, tables, emphasis, diagrams, terminology, length, and anti-patterns.
3. Include the visualizations from references/visualization.md: a skill tree (Mermaid) and a route map (Mermaid), plus a separate timeline; fall back to compact ASCII if Mermaid is unavailable.

Apply the quality gate before finishing. Recommended report order: cover header, Abstract (核心结论 + Planning Snapshot + 一句话路线), then by complexity 01 目标与现状, 02 可行性评估, 03 能力模型, 04 学习路线, 05 阶段实施方案, 06 项目与成果, 07 评估体系, 08 风险与调整, 09 最小可行路线, 10 长期演化, and end with Start Here. Add or drop chapters by complexity; a simple goal does not need all chapters.

## Quality Gate

Before final output, self-check and re-layout if any check fails:

- The core conclusion is findable immediately.
- Heading levels are stable: `#` title, `##` section, `###` subsection, `####` detail.
- Tables and bold are not overused; no prose inside table cells.
- Callouts use only Decision / Key Insight / Constraint / Warning.
- Route diagram and timeline are clear; ASCII fallback present if no Mermaid.
- Current phase, next action, next milestone, and exit criteria are explicit.
- No emoji, no repeated content, no AI-template feel.

## Principles

- Realistic, not optimistic. If the deadline cannot be met, say so and offer scoped alternatives; never silently stretch time.
- Sequence by prerequisites and dependencies, not topic popularity.
- Outcome-based phrasing ("by then I can ...") rather than completion-only.
- Prefer official and canonical sources; never fabricate course names, books, URLs, prices, or version specifics.
- Resources serve the route: give each phase a Primary / Optional / "Do not study yet" set instead of one giant list.
- Time estimates are ranges (about 6-8 hours), not false precision.
- Manage assumptions: when info is missing, state the assumption and its impact so the user can correct it.
- Do not expand scope unasked; keep goals and constraints intact.

## References

- references/intake-schema.md - Planning Context schema, intake form, fallback questionnaire.
- references/planning-framework.md - goal decomposition, skill tree, dependency engine, time budget, risk engine, minimum viable route.
- references/output-format.md - default roadmap output structure.
- references/visualization.md - mermaid and ASCII route map and timeline guidance.
- references/presentation-style.md - report typography, hierarchy, callouts, tables, emphasis, diagrams, length, and anti-patterns.
- references/examples.md - worked examples, including the 5 test scenarios.
